# BruteXSS

BruteXSS is a tool written in python simply to find XSS vulnerabilities in web application.

This tool was originally developed by Shawar Khan in CLI. I just redesigned it and made it GUI for more convienience.

This tool is developed in Python, so obviously cross platform, you just need Python installed in your machine.

# Screenshots

![Alt text](/screenshots/BruteXSS.png?raw=true "BruteXSS tool")

![Alt text](/screenshots/brutexssstart.png?raw=true "First look of BruteXSS")

![Alt text](/screenshots/brutexssaction.png?raw=true "BruteXSS in action")

![Alt text](/screenshots/bupdate.png?raw=True "BruteXSS Auto-Update feature")

# Steps

1. Just download your tool & run brutexss.py (Everything this tool needed is provided to it)

# CLI Developer : Shawar Khan
https://github.com/shawarkhanethicalhacker/BruteXSS

# GUI Developer : Rajesh Majumdar
https://github.com/rajeshmajumdar/BruteXSS

I noticed that some of you, are having problems using this tool, like it is not showing any results.I recommend you to update the tool & most of you don't select the method.

# Buy me a coffee

You can help me buying more coffee, so that I can continue turning coffee into code.

[![Donate](https://img.shields.io/badge/Donate-PayPal-green.svg)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=2LQFT9QM4M7YU)
